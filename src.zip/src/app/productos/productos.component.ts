import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.scss']
})
export class ProductosComponent implements OnInit {
  productos=[
    {
      id:'1',
      titulo:'Alarma Nemesis',
      precio:400000,
      descripcion:'Alarma Ultima Generacion NEMESIS Connect Series + Bloqueo Central de Seguros Nemesis 360 Kit 4 Puertas + Servomotor Adicional para apertura de Baul electrica Nemesis 2 Cables',
    },
    {
      id:'2',
      titulo:'Parlantes Componente Jbl',
      precio:400000,
      descripcion:'Sonido JBL profesional:Los altavoces de la serie JBL GTO son la actualización perfecta para sus altavoces existentes. Están diseñados con un material de cono inyectado con carbono para reproducir con precisión la música de la forma en que el artista la concibió originalmente.',
    },
    {
      id:'3',
      titulo:'Navegación Pantalla Android Gps',
      precio:400000,
      descripcion:'Sistema: Android 9 Memoria de ejecución: DDR 1G Memoria corporal: 16 GB Tamaño de pantalla: 10,1 pulgadas Resolución: pantalla capacitiva 1024x600 HD compatible con conexión bidireccional Android y conexión unidireccional iOS.',
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
